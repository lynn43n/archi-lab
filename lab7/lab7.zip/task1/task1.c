#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <libgen.h> // Prototype for basename() function

#define KB(i) ((i)*1<<10)
#define INT sizeof(int)
#define SHORT sizeof(short)
#define BYTE sizeof(char)

typedef struct {
  char debug_mode;
  char file_name[128];
  int unit_size;
  unsigned char mem_buf[10000];
  size_t mem_count;
  /*
   .
   .
   Any additional fields you deem necessary
  */
} state;


state s;
state* sta=&s ;





// turn on debug mode

void toggle(state* s){
     s->debug_mode=1- s->debug_mode;
    if(s->debug_mode==1){
        printf("Debug mode is currently on\n");
    }
}


void setName(state* s){
    fgets(s->file_name, 100, stdin);
    sscanf(s->file_name,"%s\n",s->file_name);
    if(sta->debug_mode==1){
         printf("Debug: file name set to %s\n",s->file_name);
    }
    
}

void setUnit(state* s){
     int num;
    char number[4];
    printf("please enter a valid unit size:\n");
    fgets(number,4,stdin);
    sscanf(number,"%d\n",&num);
    if(num ==1 ||num==2 || num==4){
        s->unit_size=num;
        if(s->debug_mode){
            printf("Debug: set size to %d\n", num);
        }
    }
    else{
       printf("Error: size not valid\n"); 
    }
    
}

void loadMemo(state * s){  
    int location, length;
    char locAndLen[32];
    FILE * inp;
    
    if(s->file_name==NULL){
        printf("Error: no file name\n");
        return;
    }
    inp=fopen(s->file_name,"r+");
    
    if(inp== NULL){
        perror("fopen");
        return;
    }
    printf("Please enter <location> <length>\n");
    fgets(locAndLen,32,stdin);
    sscanf(locAndLen,"%X %d\n",&location ,&length);
    if(sta->debug_mode==1){
         printf("Debug: file name %s\nlocation: %x\nlength: %d\n", s->file_name, location, length);
    }
    //todo: read to memo
    fseek(inp, length*s->unit_size, SEEK_SET); //we want to read from file from the location the user entered
    fread(sta->mem_buf, sta->unit_size,length,inp );
    if(sta->debug_mode==1){
        printf("Loaded %d units into memory\n", length*s->unit_size);
    }
    fclose(inp);
    
}


char* unit_to_format(int unit) {
    static char* formats[] = {"%#hhu\t%#hhx\n", "%#hu\t%#hx\n", "No such unit", "%#u\t%#x\n"};
    return formats[sta->unit_size-1];
   
}  


/************ These are the functions that actually do the work ***************/
/* Reads units from file */
void read_units_to_memory(FILE* input, char* buffer, int count) {
    fread(buffer, sta->unit_size, count, input);
    
}

/* Prints the buffer to screen by converting it to text with printf */
void print_units(FILE* output, char* buffer, int count) {
    char* end = buffer + sta->unit_size*count;
    while (buffer < end) {
        //print ints
        int var = *((int*)(buffer));
        fprintf(output, unit_to_format(sta->unit_size), var);
        buffer += sta->unit_size;
    }
}

/* Writes buffer to file without converting it to text with write */
void write_units(FILE* output, char* buffer, int count) {
    fwrite(buffer, sta->unit_size, count, output);
}
/*****************************************************************************/




void displayMemo(state * s){
  int u, addr;
    char uAndaddr[32];
    char *virMem; 
    printf("Please enter <unit_size> <address>\n");
    fgets(uAndaddr,32,stdin);
    sscanf(uAndaddr,"%d %X\n",&u ,&addr);
    printf("Decimal   Hexadecimal\n=============\n");
    if(addr==0){
        virMem= (char *)s->mem_buf;
    }
    else{
        virMem=(char *)addr;
    }
    print_units(stdout,virMem,u);
}



void saveToFile(state *s){
   int src=0;
    int target, len;
    char *virMem; 
    char input[64];
    FILE * inp;
    
    if(s->file_name==NULL){
        printf("Error: no file name\n");
        return;
    }
    inp=fopen(s->file_name,"r+");
    if(inp== NULL){
        perror("fopen");
        return;
    }    
    printf("Please enter <source-address> <target-location> <length>\n");
    fgets(input,64,stdin);
    sscanf(input,"%X %X %d\n",&src ,&target,&len);
    
    if(strlen(s->file_name)<target){
        printf("Error: target greater than length of name\n");
        return;
    }
    if(src==0){
        virMem= (char *)s->mem_buf;
    }else{
        virMem=(char *)src;
    }
    
    fseek(inp,target,SEEK_SET);
    write_units(inp,virMem,len);
    fclose(inp);
    
}

void modifyFile(state *s){
      int loc, val;
    FILE * inp;
    char input[64];
    char * virMem;
    if(s->file_name==NULL){
        printf("Error: no file name\n");
        return;
    }
    inp=fopen(s->file_name,"r+");
    if(inp== NULL){
        perror("fopen");
        return;
    }    
    printf("Please enter <location> <val>\n");
    fgets(input,64,stdin);
    sscanf(input,"%X %X\n",&loc ,&val);

    if(sta->debug_mode==1){
        printf("location: %X value: %X\n",loc,val);
    }
    virMem=(char *)&val;
    fseek(inp,loc,SEEK_SET);
    write_units(inp,virMem,1);
    fclose(inp);

}


void quit(state* s){
    if(s->debug_mode){
        printf("quitting\n"); 
    }
    exit(0);
}

struct fun_desc {
  char *name;
  void (*fun)(state*);
};



struct fun_desc menu_display[] = {{"Toggle Debug Mode", toggle}, {"Set File Name", setName}, {"Set Unit Size",setUnit }, {"Load Into Memory",loadMemo}, {"Memory Display",displayMemo},{"Save Into File",saveToFile},{"File Modify",modifyFile}, {"Quit", quit}, {NULL, NULL}};






int main(int argc, char **argv) {
    int func_option;
    char c;
    sta->unit_size=1;
    while(1){
        if(sta->debug_mode==1){
            printf("Unit size:%d\t filename:%s\t memcount:%d\n",sta->unit_size,sta->file_name,sta->mem_count);
        }
        printf("Choose action:\n");
        for (int i = 0; i < 8; ++i)
            printf("%i-%s\n", i, menu_display[i].name);
        
        c= fgetc(stdin);
        fgetc(stdin);
       if((c>='0') && (c<='7')){
           func_option=atoi(&c);
            menu_display[func_option].fun(sta);
        }else{
           if(c!='\n'){
                printf("Not within bounds\n");
                quit(0);
            }           
        }
    }
    return 1;


}
