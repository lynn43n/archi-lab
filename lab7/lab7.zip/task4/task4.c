#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <libgen.h> // Prototype for basename() function


int digit_cnt(char *c){
    int length_str;
    int sum= 0;
    char* digit;
    length_str= strlen(argv[1]);
    
    for( int i= 0; i< length_str; i++){
        digit=c[i];
        if(c<='9' && c>='0'){
            sum++;
        }
    }
    return sum;
}

int main(int argc, char **argv) {
    char *c;
    int sum;
    c=argv[1]
    sum= counter(c);
    return sum;
    
}
