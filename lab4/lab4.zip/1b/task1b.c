#include "util.h"
#define SYS_OPEN 5
#define SYS_CLOSE 6
#define SYS_READ 3
#define SYS_WRITE 4
#define SYS_LSEEK 19
#define STDERR 2
#define STDOUT 1
#define STDIN 0


#define SYS_CALL(sysid, arg1, arg2, arg3, debug) wrap_sys(system_call(sysid, arg1, arg2, arg3), sysid, debug)



int wrap_sys (int res, int sys_id, int debug){
    
    if(debug == 1){
        char *debug_print = itoa(sys_id);
        system_call(4, 2, "opcode: ", strlen("opcode: "));
        system_call(SYS_WRITE, 2, debug_print, strlen(debug_print)); /*print the id*/
        system_call(4, 2, "ret value: ", strlen("ret value: "));
        char *debug_print2 = itoa(res);
        system_call(4, 2, debug_print2, strlen(debug_print2));
        system_call(4, 2, "\n", strlen("\n"));

    }
    if(res < 0){
        system_call(4, 2, "EROOR\n", strlen("ERROR\n"));
    }
    return res;
}

int main(int argc, char **argv) {
	int debug=0;
    int fileIn=0;
    int fileOut=0;
   
	int input;	
  	int output;
  
	char * in;
	char * out;
	int i;
   
	for(i=1; i<argc; i++){
        if(strncmp(argv[i],"-D",2)==0){
            debug=1;
        }
        else if(strncmp(argv[i],"-i",2)==0){
            fileIn=1;
            in= argv[i]+2;
            input=  system_call(SYS_OPEN,  in, 2, 0777);
           if(input < 0){
                SYS_CALL(4, 2, "ERROR\n", strlen("ERROR\n"), debug);
            }
        }
         else if(strncmp(argv[i],"-o",2)==0){
            fileOut=1;
            out= argv[i]+2;
            output=system_call(SYS_OPEN, out,65 ,0777);
            
           if(output < 0){
                SYS_CALL(4, 2, "ERROR\n", strlen("ERROR\n"), debug);
            }
        }
        else{
              system_call(1,1);
        }
    }

    if(debug==1){
        system_call(SYS_WRITE,STDERR,"-D",2); 
        system_call(SYS_WRITE,STDERR,"\n",1);
        
    }



 char c;
    
   while(SYS_CALL(3, input, &c, 1, debug) > 0){
        char toprint = c;
        if(c >= '0' && c <= '9'){
            toprint = toprint + ('A' - '0');
        }

        SYS_CALL(4, output, &toprint, 1, debug);
    }
                           

    if(fileIn == 1){
        SYS_CALL(6, input, 69, 69, debug);
    }
    if(fileOut == 1){
        SYS_CALL(6, output, 69, 69, debug);
    }


    return 0;
}
    

