#include <dirent.h>     /* Defines DT_* constants */
#include <stdio.h>
#include <sys/types.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <unistd.h>
#include <signal.h>
#include <linux/limits.h>
#include "LineParser.h"
#include <sys/wait.h>
#include <time.h>

#define TERMINATED  -1
#define RUNNING 1
#define SUSPENDED 0

typedef struct process{
    cmdLine* cmd;                         /* the parsed command line*/
    pid_t pid; 		                  /* the process id that is running the command*/
    int status;                           /* status of the process: RUNNING/SUSPENDED/TERMINATED */
    struct process *next;	                  /* next process in chain */
} process;


//global freeProcessList first we intilize it by pointing to NULL
char * status_str[]= {"TERMINATED","SUSPENDED","RUNNING"};
process *temp= NULL;
process **global_pro_lst= &temp;

void printProcessList(process** process_list){
    int i=0;
    printf("\n");
    printf("PID\tCommand\tSTATUS\n");
    
    while ( process_list[i] != NULL) {                             // i think it should be (process_list[i]-> next !=NULL)
        printf("%d\t", process_list[i]->pid);
        printf("%s\t", process_list[i]->cmd->arguments[0]);
        
        printf("%s\t", status_str[(process_list[i]->status)+1]);
        printf("\n");
        *process_list= process_list[i]->next;
        i++;
     }
    
}

void addProcess(process** process_list, cmdLine* cmd, pid_t pid){
    process *new_process;
    new_process=(process*) malloc(sizeof(struct process));
    new_process->cmd= cmd;
    new_process->pid=pid;
    new_process->status=RUNNING;
    new_process->next=*process_list;
    *process_list= new_process;
}

void freeProcessList(process* process_list){
    if(process_list!=NULL){
        free(process_list->next);
        freeProcessList(process_list->next);
        free(process_list);
    }
}

void updateProcessList(process **process_list){

    
}

void updateProcessStatus(process* process_list, int pid, int status){
    
}


cmdLine * execute(cmdLine *pCmdLine){
    int childID;
    int status;
    
   
    if((childID = fork()) == 0){
        status= execvp(pCmdLine->arguments[0], pCmdLine->arguments);
        
    }else if (childID == -1) {
        perror("fork failed");
        _exit(EXIT_FAILURE);
        
    }else{
        if(pCmdLine->blocking ==1){
            waitpid(childID, &status,  0);
        }
    }
    addProcess(global_pro_lst,pCmdLine,childID);
    return 0;
}


void debugOn(){
    
    
}

int main(int argc, char **argv) {    
   char buffer[2048];
   cmdLine *pCmdLine;
   char current_path[PATH_MAX];

    //int debug =0;
   
   
   
    while(1){
        if (getcwd(current_path, sizeof(current_path)) == NULL){
            perror("getcwd() error");
        }
        else{
            printf("current working directory is: %s\n", current_path);
        }
        
        if(fgets(buffer, 2048, stdin)!= NULL){            
            if(strncmp(buffer, "quit", 4)==0){ 
                exit(0);   
            }
            else if(strncmp(buffer,"cd",2)==0 ){
                int ret;
                strtok((buffer+3), "\n");
                printf("\nGOT = %s\n",(buffer+3));
                
                ret = chdir ((buffer+3));
                if(ret!=0){
                    perror("Error: chdir");
                }
            }
            else if(strncmp(buffer,"procs",5)==0 ){
                printProcessList(global_pro_lst);    
                
            }
            else{
                if((pCmdLine=(parseCmdLines(buffer)))!= NULL){
                        execute(pCmdLine);
                   }
                }
            }
        }
return 0;

}
