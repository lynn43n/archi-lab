#include <dirent.h>     /* Defines DT_* constants */
#include <stdio.h>
#include <sys/types.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <unistd.h>
#include <signal.h>
#include <linux/limits.h>
#include "LineParser.h"
#include <sys/wait.h>
#include <time.h>

#define TERMINATED  -1
#define RUNNING 1
#define SUSPENDED 0

typedef struct process{
    cmdLine* cmd;                         /* the parsed command line*/
    pid_t pid; 		                  /* the process id that is running the command*/
    int status;                           /* status of the process: RUNNING/SUSPENDED/TERMINATED */
    struct process *next;	                  /* next process in chain */
} process;


 int debug =0;
   
   

cmdLine * execute(cmdLine *pCmdLine){
    int childID;
    int status;
    
   
    if((childID = fork()) == 0){        
        status= execvp(pCmdLine->arguments[0], pCmdLine->arguments);
        if(debug){
            fprintf(stderr, "PID: %d\n",childID);
            fprintf(stderr, "executing command: %s\n",pCmdLine->arguments[0]);
            
        }
        
        
    }else if (childID == -1) {
        perror("fork failed");
        _exit(EXIT_FAILURE);
        
    }else{
        if(pCmdLine->blocking ==1){
            waitpid(childID, &status,  0);
        }
         if(debug){
            fprintf(stderr, "PID: %d\n",childID);
            fprintf(stderr, "executing command: %s\n",pCmdLine->arguments[0]);
            
        }
    }
  
    return 0;
}




int main(int argc, char **argv) {    
   char buffer[2048];
   cmdLine *pCmdLine;
   char current_path[PATH_MAX];

   
   
    while(1){
        if (getcwd(current_path, sizeof(current_path)) == NULL){
            perror("getcwd() error");
        }
        else{
            printf("current working directory is: %s\n", current_path);
        }
        
        if(fgets(buffer, 2048, stdin)!= NULL){            
            if(strncmp(buffer, "quit", 4)==0){ 
                exit(0);   
            }
            else if(strncmp(buffer,"cd",2)==0 ){
                int ret;
                strtok((buffer+3), "\n");
                ret = chdir ((buffer+3));
                if(ret!=0){
                    perror("Error: chdir");
                }
            }else if(strncmp(buffer,"-d",2)==0 ){
                debug=1;
            }
            else{
                if((pCmdLine=(parseCmdLines(buffer)))!= NULL){
                        
                        execute(pCmdLine);
                   }
                }
            }
        }
return 0;

}
