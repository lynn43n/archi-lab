#include <sys/mman.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <assert.h>
#include <elf.h>
#include <stdio.h>
#include <stdlib.h>

struct fun_desc {
  char *name;
  void (*fun)();
};

int debug_mode = -1; /*-1 for off and 1 for on*/
struct stat fd_stat; /*CLASS MATERIAL: this is needed to  the size of the file */
Elf32_Ehdr *header;  /*CLASS MATERIAL: this will point to the header structure, the general information about the ELF file */
void *map_start;     /*CLASS MATERIAL: will point to the start of the memory mapped file */
int Currentfd = -1;  /*holding file discriptor of a file that was loading recently*/

Elf32_Shdr *section_header;
Elf32_Sym *symbol_table_entry;

void print_information_int(char* text, int the_state)
{
    
    printf(text);
    printf("\t");
    printf("%d\n",the_state);
}









void toggleDebugMode() 
{
    
    debug_mode=debug_mode*-1;
    
    if(debug_mode==1)
        printf("Debug is off\n");

    else
        printf("Debug flag now on\n");
}










void Examine_ELF_File() {
    

    char filename[100];
    int success_operation=0;
    printf("please enter an ELF file name: \n" );
    gets(filename);
    
    /*closing previous files*/
    if(Currentfd != -1)
        close(Currentfd);
    
    /*opening file*/
    Currentfd = open(filename, O_RDWR);

    /*error ocured during opening*/
    if (Currentfd == -1) 
    {
        printf("error ocured during file opening");
        exit(-1);
    }
    
    
    /*function return information about the state*/
    success_operation = fstat(Currentfd, &fd_stat);
    if(success_operation != 0) { 
      perror("stat failed");
      exit(-1);
   }
   
   /*function from class material check if mmap was successful*/
      if ( (map_start = mmap(0, fd_stat.st_size, PROT_READ | PROT_WRITE , MAP_SHARED, Currentfd, 0)) == MAP_FAILED ) {
      perror("mmap failed");
      exit(-4);
   }
    
    /*CLASS MATERIAL: the casting, after that file is mapped starting at map_start*/
    header = (Elf32_Ehdr*)map_start; 

    
    
    /*magic numbers*/
    printf("Bytes 1,2,3 of the magic number: %c, %c, %c\n", header->e_ident[EI_MAG1], header->e_ident[EI_MAG2], header->e_ident[EI_MAG3]);
    
    printf("The data encoding scheme of the object file:\t");
    if(header->e_ident[EI_DATA]==1) /*e_ident is the 1 field, EI_data indicate the decoding verison*/ 
        printf("little endian\n");
    else 
        printf("big endian\n");
    
    printf("Entry point: %X\n", header->e_entry); /*field 5*/

    print_information_int("The file offset in which the section header table resides",header->e_shoff);          /*This member holds the section header table’s file offset, field 7*/
    
    print_information_int("The number of section header entries:", header->e_shnum);                    /*This member holds the number of entries in the section header table, field 13*/
    
    print_information_int("The size of each section header entry:", header->e_shentsize); /*the product of e_shentsize and e_shnum gives section header table’s size in bytes, field 12*/
    
    print_information_int("The file offset in which the program header table resides:",header->e_phoff);
    
    print_information_int("The number of program header entriess:",header->e_phnum);
    
    printf("\n\n");
    

}



void PrintSectionNames() {
    if (Currentfd == -1){
        perror("Currentfd is invalid");
    }
    else{
    
    int index_of = map_start + header->e_shoff;
    Elf32_Shdr *section_header=(Elf32_Shdr*)(index_of);

    char *section_header_table = (char*)(map_start + section_header[header->e_shstrndx].sh_offset);

   /*printf("index    address     offset      size    type");*/

   printf("%s\t %-20s %s\t %s\t %s\t %s\n\n", "index", "name", "address", "offset", "size", "type"); 

    int i;
    int size= header->e_shnum;
    for(i = 0; i < size; i++){
        
        if(section_header[i].sh_type==0)
            printf("[%d]\t %-20s %08X\t %06X\t %d\t %s\n", i, section_header_table + section_header[i].sh_name, section_header[i].sh_addr,
               section_header[i].sh_offset, section_header[i].sh_size, "NULL");
            
        else if(section_header[i].sh_type==1)
        {
                printf("[%d]\t %-20s %08X\t %06X\t %d\t %s\n", i, section_header_table + section_header[i].sh_name, section_header[i].sh_addr,
                section_header[i].sh_offset, section_header[i].sh_size, "PROGBITS");
        }
        
        else if(section_header[i].sh_type==2)
        {
                printf("[%d]\t %-20s %08X\t %06X\t %d\t %s\n", i, section_header_table + section_header[i].sh_name, section_header[i].sh_addr,
                section_header[i].sh_offset, section_header[i].sh_size, "SYMTAB");                    
        }
        
        else if(section_header[i].sh_type==3)
        {        
                printf("[%d]\t %-20s %08X\t %06X\t %d\t %s\n", i, section_header_table + section_header[i].sh_name, section_header[i].sh_addr,
                section_header[i].sh_offset, section_header[i].sh_size, "STRTAB");
        }
        else if(section_header[i].sh_type==4)
        {        
                printf("[%d]\t %-20s %08X\t %06X\t %d\t %s\n", i, section_header_table + section_header[i].sh_name, section_header[i].sh_addr,
                section_header[i].sh_offset, section_header[i].sh_size, "SHT_RELA");
        }
        else if(section_header[i].sh_type==5)
        {        
                printf("[%d]\t %-20s %08X\t %06X\t %d\t %s\n", i, section_header_table + section_header[i].sh_name, section_header[i].sh_addr,
                section_header[i].sh_offset, section_header[i].sh_size, "SHT_HASH");
        }
        else if(section_header[i].sh_type==6)
        {        
                printf("[%d]\t %-20s %08X\t %06X\t %d\t %s\n", i, section_header_table + section_header[i].sh_name, section_header[i].sh_addr,
                section_header[i].sh_offset, section_header[i].sh_size, "SHT_DYNAMIC");
        }
        else if(section_header[i].sh_type==7)
        {        
                printf("[%d]\t %-20s %08X\t %06X\t %d\t %s\n", i, section_header_table + section_header[i].sh_name, section_header[i].sh_addr,
                section_header[i].sh_offset, section_header[i].sh_size, "SHT_NOTE");
        }
         else if(section_header[i].sh_type==8)
        {        
                printf("[%d]\t %-20s %08X\t %06X\t %d\t %s\n", i, section_header_table + section_header[i].sh_name, section_header[i].sh_addr,
                section_header[i].sh_offset, section_header[i].sh_size, "SHT_NOBITS");
        }
         else if(section_header[i].sh_type==9)
        {        
                printf("[%d]\t %-20s %08X\t %06X\t %d\t %s\n", i, section_header_table + section_header[i].sh_name, section_header[i].sh_addr,
                section_header[i].sh_offset, section_header[i].sh_size, "SHT_SHLIB");
        }
         else if(section_header[i].sh_type==10)
        {        
                printf("[%d]\t %-20s %08X\t %06X\t %d\t %s\n", i, section_header_table + section_header[i].sh_name, section_header[i].sh_addr,
                section_header[i].sh_offset, section_header[i].sh_size, "SHT_DYNSYM");
        }
        else
        {    
           printf("[%d]\t %-20s %08X\t %06X\t %d\t %s\n", i, section_header_table + section_header[i].sh_name, section_header[i].sh_addr,
                section_header[i].sh_offset, section_header[i].sh_size, "");
        }
       
    }
}

}






void Print_Symbols ()
{
    int i;
     if (Currentfd == -1) {
        perror("Currentfd is invalid");
    }
    else{
        
    int location = map_start + header->e_shoff;    
    section_header = (Elf32_Shdr *)(location);                    /*begining of section header array*/
    
    int string_table_offset=map_start + section_header[header->e_shstrndx].sh_offset; /*address ------> header string table reaching it by e_shstrndx*/
    
    char *sections_header_string_table = (char*)(string_table_offset); /*the names in string taable of sections heaader*/
    
    
    /*moving on section header table entries*/
    int number_of_sections=header->e_shnum;
    
    for (i = 0; i < number_of_sections; i++) 
    { 
        if (section_header[i].sh_type == 2) {       /* Symbol table or dyn_sym */
            
            Elf32_Sym *symbol_table_entry = (Elf32_Sym *) (map_start + section_header[i].sh_offset);    /*point to the entry that belong to the section header*/
            /*int size_of_table = section_header[i].sh_size / sizeof(Elf32_Sym);     /* Section size in bytes /Symbol table entry.  */
            
            int address=section_header[section_header[i].sh_link].sh_offset + map_start;
            
            char *symbol_entry_string_table = (char *)(address); /*point to the string table of this symbol table*/
            
            printf("\n");
            printf("[index]\t value\t\t section_index\t section_name\t symbol_name\n");
            int j;
            for (j = 0; j < section_header[i].sh_size / sizeof(Elf32_Sym); j++) 
            {
              if(symbol_table_entry[j].st_shndx!=SHN_LORESERVE || symbol_table_entry[j].st_shndx!=SHN_LOPROC || symbol_table_entry[j].st_shndx!=SHN_HIPROC || 
                  symbol_table_entry[j].st_shndx!=SHN_ABS || symbol_table_entry[j].st_shndx!=SHN_COMMON || symbol_table_entry[j].st_shndx!=SHN_HIRESERVE)
              {

                  printf("[%d]\t %08X\t %d\t\t %s\t\t %s\n", j, symbol_table_entry[j].st_value, symbol_table_entry[j].st_shndx, sections_header_string_table + section_header[i].sh_name ,symbol_entry_string_table + symbol_table_entry[j].st_name);
              }
                
            }
        }
    }

    printf("\n");

}

}




void  link_Check(){
    
    int i;
     if (Currentfd == -1) {
        perror("Currentfd is invalid");
    }
    else{
    section_header = (Elf32_Shdr *) (map_start + header->e_shoff);                    /*begining of section header array*/
    
    int string_table_offset=map_start + section_header[header->e_shstrndx].sh_offset; /*address ------> header string table reaching it by e_shstrndx*/
    
    char *sections_header_string_table = (char*)(string_table_offset); /*the names in string taable of sections heaader*/
    
    
    /*moving on section header table entries*/
    int number_of_sections=header->e_shnum;
    printf("\nOffset\t Info\n");
    for (i = 0; i < number_of_sections; i++) 
    { 
        if (section_header[i].sh_type == SHT_REL ) {/* Symbol table or dyn_sym */
            
            Elf32_Rel *REL_entry = (Elf32_Rel *) (map_start + section_header[i].sh_offset);    /*point to the entry that belong to the section header*/
            int size_of_table = section_header[i].sh_size / sizeof(Elf32_Rel);     /* Section size in bytes /Symbol table entry.  */
            
            
            
            
            
            
            char *REL_entry_string_table = (char *) (section_header[section_header[i].sh_link].sh_offset + map_start);
            
            Elf32_Sym *symbol_table_entry = (Elf32_Sym *) (map_start + section_header[i].sh_offset);    /*point to the entry that belong to the section header*/
            
            int j;
            for (j = 0; j < size_of_table; j++) 
            {
                
                  printf("%X\t%X\n", (REL_entry+j)->r_offset, (REL_entry+j)->r_info);
            
                
            }
         
        
            }
        }
    }

    printf("\n");

}


void relocate_Check()
{
 void * symtbl;
    int i;
     if (Currentfd == -1) {
        perror("Currentfd is invalid");
    }
    else{
    section_header = (Elf32_Shdr *) (map_start + header->e_shoff);                    /*begining of section header array*/
    
    int string_table_offset=map_start + section_header[header->e_shstrndx].sh_offset; /*address ------> header string table reaching it by e_shstrndx*/
    
    char *sections_header_string_table = (char*)(string_table_offset); /*the names in string taable of sections heaader*/
    
    
    /*moving on section header table entries*/
    int number_of_sections=header->e_shnum;
    printf("\nOffset\t Info\n");
    
    
    
    for (i = 0; i < number_of_sections; i++) 
    { 
        
        if(section_header[i].sh_type == 11){
            symtbl=(map_start + section_header[i].sh_offset) ;
        }
        
        if (section_header[i].sh_type == SHT_REL ) {/* Symbol table or dyn_sym */
            
            Elf32_Rel *REL_entry = (Elf32_Rel *) (map_start + section_header[i].sh_offset);    /*point to the entry that belong to the section header*/
            int size_of_table = section_header[i].sh_size / sizeof(Elf32_Rel);     /* Section size in bytes /Symbol table entry.  */
            
            
            
            int index_of=ELF32_R_SYM(REL_entry->r_info);
            
            
            
            
            /*char *REL_entry_string_table = (char *)section_header[index_of] + map_start);*/
            
            Elf32_Sym *symbol_table_entry = (Elf32_Sym *) (map_start + section_header[i].sh_offset);    /*point to the entry that belong to the section header*/
            
            int j;
            for (j = 0; j < size_of_table; j++) 
            {
                
                  printf("%X\t%X\n", (REL_entry+j)->r_offset, (REL_entry+j)->r_info);
            
                
            }
         
        
            }
        }
    }

    printf("\n");
    
    
}













void quit(){
    close(Currentfd);
    exit(0);
}











int main(int argc, char** argv){
    
    int i;  /*for loop iteration*/
    int choose; /*function to choose*/
    char input [100]; /*hold input from user*/
    
    struct fun_desc menu[] = { {"Toggle Debug Mode", toggleDebugMode}, {"Examine ELF File",Examine_ELF_File },
                               {"Print Section Names", PrintSectionNames},{"Print Symbols",Print_Symbols},{"Link check", link_Check},{"Relocation Tables", relocate_Check},{"Quit", quit}, {NULL , NULL}};
    

    while (1){
        printf("Please choose an action: \n");
        for(i = 0; menu[i].name != NULL ; i++){
            printf("%d - %s \n", i, menu[i].name);
        }

        fgets(input,100,stdin);
        sscanf(input,"%d",&choose);

        menu[choose].fun();
        
    }

}
















